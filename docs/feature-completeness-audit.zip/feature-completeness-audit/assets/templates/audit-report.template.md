# Auditoria — <Área Auditada> — <YYYY-MM-DD>

## Sumário executivo

**Status geral:** 🔴 Crítico / 🟠 Alto / 🟡 Médio / 🟢 OK

**Contagem de gaps:**
- 🔴 Críticos: <n>
- 🟠 Altos: <n>
- 🟡 Médios: <n>
- 🟢 Baixos: <n>

**Veredictos:**
- Pode mostrar pra cliente em demo? **Sim / Não / Com ressalvas**
- Pode entrar em produção? **Sim / Não / Com ressalvas**
- Está vendável? **Sim / Não / Falta <X>**

**Tempo estimado para deixar verde:** <horas / dias>

---

## Inventário

### Rotas auditadas
- `<rota 1>` — <descrição>
- `<rota 2>` — <descrição>

### Tabelas envolvidas
- `<tabela 1>` — <colunas chave>
- `<tabela 2>` — <colunas chave>

### Integrações em uso
- <ferramenta 1> — <para quê>
- <ferramenta 2> — <para quê>

### Telas verificadas
- <tela 1>
- <tela 2>

---

## Achados por dimensão

### Dimensão 1 — Funcional

#### 🔴 Crítico — <título do gap>
- **Onde:** `<arquivo / rota>`
- **Reprodução:**
  1. <passo 1>
  2. <passo 2>
  3. <resultado observado>
- **Esperado:** <o que deveria acontecer>
- **Evidência:** <screenshot, log, console error>
- **Ação recomendada:** <o que fazer>

#### 🟠 Alto — <título>
...

#### 🟡 Médio — <título>
...

#### Pontos positivos
- <o que está bom nesta dimensão>

---

### Dimensão 2 — Dados

#### 🔴 Crítico — <título>
- **Onde:** <tabela / migration / query>
- **Problema:** <descrição>
- **Evidência:** <consulta SQL, screenshot do dashboard>
- **Ação recomendada:** <o que fazer>

...

#### Pontos positivos
- <o que está bom nesta dimensão>

---

### Dimensão 3 — Integrações

#### 🔴 Crítico — <título>
- **Integração:** <Z-API / Resend / Stripe / etc.>
- **Onde:** <Edge Function / chamada outbound / webhook>
- **Problema:** <descrição>
- **Logs relevantes:**
  ```
  <trecho de log>
  ```
- **Ação recomendada:** <o que fazer>

...

#### Pontos positivos
- <o que está bom nesta dimensão>

---

### Dimensão 4 — UX/Visual

#### 🟠 Alto — <título>
- **Tela:** <rota>
- **Viewport:** desktop / mobile / dark mode
- **Problema:** <descrição>
- **Evidência:** <screenshot ou descrição visual>
- **Ação recomendada:** <o que fazer>

...

#### Pontos positivos
- <o que está bom nesta dimensão>

---

### Dimensão 5 — Comercial

#### Resposta ao teste do "e daí?"
Aplicado à área auditada:
- "Tem <feature>." E daí?
- "<resposta>" E daí?
- "<resposta>" E daí?
- "<chega ou não a valor de negócio?>"

#### Resposta ao teste do print do WhatsApp
Se mandar print pro cliente, ele entende o valor sem explicação? **Sim / Não / Parcialmente**

#### Resposta ao teste da demo de 5 minutos
Dá pra mostrar essa área em 5 minutos e gerar interesse? **Sim / Não / Com edição**

#### Gaps comerciais
- 🔴/🟠/🟡 <descrição do gap comercial>

#### Pontos positivos comerciais
- <o que está bom comercialmente>

---

## Plano de ataque sugerido

Ordem priorizada de correção, considerando dependências:

### Sprint 1 — Críticos (bloqueiam tudo)
1. <gap crítico 1>
2. <gap crítico 2>

### Sprint 2 — Altos (cliente vai notar)
1. <gap alto 1>
2. <gap alto 2>

### Sprint 3 — Médios (antes de produção)
1. <gap médio 1>
2. <gap médio 2>

### Backlog — Baixos (polish)
- <gap baixo 1>
- <gap baixo 2>

---

## Resposta à pergunta final

> "Em uma frase, qual é o motivo pelo qual o cliente vai pagar pelo Veltzy / por esta feature?"

<resposta clara em uma frase>

**Esta auditoria reforça ou enfraquece essa resposta?** <reforça / enfraquece / neutra, justificar>

---

## Próximos passos sugeridos

- [ ] Criar Spec via `/spec` para o bloco de gaps críticos
- [ ] Implementar correção via `/implement`
- [ ] Reauditar após correções (rodar `/audit <area>` de novo)
- [ ] <outros próximos passos específicos>

---

*Auditoria gerada em <data> usando a skill `feature-completeness-audit`.*
