# Dimensão 2 — Dados

## Pergunta central

A feature persiste o que diz que persiste, e os dados podem ser confiavelmente recuperados?

## Checklist de inventário

Antes de testar, listar:

1. Todas as **tabelas** envolvidas na área auditada
2. Todas as **colunas** sendo lidas ou escritas pela feature
3. Todas as **queries** (selects, inserts, updates, deletes) executadas
4. Todas as **migrations** aplicadas relacionadas
5. Todas as **policies de RLS** que afetam a feature

## Checklist de verificação

### Schema do banco

- [ ] Todas as tabelas previstas existem no Supabase Dashboard
- [ ] Todas as colunas têm o tipo correto
- [ ] Constraints (NOT NULL, UNIQUE, FOREIGN KEY) estão aplicadas
- [ ] Índices existem para colunas usadas em filtros frequentes
- [ ] `created_at` e `updated_at` configurados onde fazem sentido
- [ ] `moddatetime()` funciona se for usado (extensão habilitada)

### RLS e segurança

- [ ] RLS está habilitado em **todas** as tabelas com dados de usuário
- [ ] Policies cobrem SELECT, INSERT, UPDATE e DELETE conforme necessário
- [ ] Policies usam `auth.uid()` corretamente para isolamento por usuário
- [ ] Multi-tenancy está respeitado (filtragem por `empresa_id` ou similar)
- [ ] Service role key é usada apenas em Edge Functions e contextos confiáveis
- [ ] Anon key não dá acesso a dados que não deveria

### Tipos TypeScript

- [ ] `src/types/database.ts` está atualizado após última migration
- [ ] Tipos batem com o schema real do banco
- [ ] Nenhum `any` em funções que tocam o banco
- [ ] Tipos são importados e usados em componentes que renderizam dados

### Operações CRUD

Para cada operação que a feature executa:

#### CREATE
- [ ] O registro é criado com todos os campos obrigatórios
- [ ] Defaults são aplicados corretamente (uuid, timestamps)
- [ ] Foreign keys apontam para registros existentes
- [ ] Erro de constraint retorna mensagem útil pro usuário
- [ ] Dado criado é imediatamente visível nas listagens (sem precisar reload)

#### READ
- [ ] Query retorna apenas o que deveria (RLS funcionando)
- [ ] Paginação funciona quando há muitos registros
- [ ] Ordenação default faz sentido para o uso
- [ ] Filtros aplicados retornam resultados corretos
- [ ] Busca por texto funciona se houver
- [ ] Joins retornam dados relacionados corretamente

#### UPDATE
- [ ] Atualização persiste no banco (verificar via Dashboard)
- [ ] `updated_at` é atualizado automaticamente
- [ ] Conflitos de concorrência são tratados (last-write-wins ou explícito)
- [ ] Mudança aparece imediatamente na UI

#### DELETE
- [ ] Soft delete vs hard delete está claro e consistente
- [ ] Cascades funcionam corretamente (FK ON DELETE)
- [ ] Confirmação obrigatória para deletes irreversíveis
- [ ] Item deletado some imediatamente da UI

### Realtime (se aplicável)

- [ ] Subscriptions fecham quando componente desmonta
- [ ] Reconexão automática funciona
- [ ] Mudanças aparecem sem reload em outras abas/usuários

## Verificação de correlação

- [ ] Dado criado em um fluxo aparece corretamente em outro fluxo que deveria mostrar
- [ ] Updates em um componente disparam re-fetch ou invalidação onde necessário
- [ ] Cache (React Query, SWR, Zustand) não fica stale após mutations
- [ ] Múltiplos usuários simultaneamente não geram inconsistência

## Como executar a verificação

1. Abrir Supabase Dashboard em uma aba
2. Subir o ambiente local em outra aba
3. Para cada operação CRUD:
   - Executar a operação no app
   - Confirmar imediatamente no Dashboard que o dado foi gravado correto
   - Recarregar a página do app e confirmar que o dado persistiu
4. Testar RLS:
   - Logar com um usuário, criar dado
   - Logar com outro usuário, confirmar que NÃO vê o dado do primeiro
5. Testar limites:
   - Criar 100 registros e ver se a paginação aguenta
   - Tentar criar registro inválido e ver se a mensagem de erro é clara

## Sinais clássicos de gap de dados

- App diz "salvo!" mas o registro não está no banco
- Dado existe no banco mas não aparece na UI
- Usuário A vê dado do usuário B (RLS faltando)
- Tipos do TypeScript discordam do banco real (migration sem regen de tipos)
- Update aparente que não persiste após reload
- `updated_at` não muda em updates (`moddatetime()` não habilitado)
- Foreign key apontando pra registro inexistente
- Cache stale mostra dado antigo após mudança

Cada um desses vai pro relatório.

## Comandos úteis para o Supabase

```bash
# Regenerar tipos após migration
npx supabase gen types typescript --project-id <ref> > src/types/database.ts

# Ver migrations aplicadas
npx supabase db remote commit list

# Conferir status RLS de todas as tabelas
# (rodar no SQL Editor do Dashboard)
SELECT schemaname, tablename, rowsecurity
FROM pg_tables
WHERE schemaname = 'public';
```
