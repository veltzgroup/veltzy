# Dimensão 4 — UX e Visual

## Pergunta central

A feature parece um produto profissional, ou parece uma demo improvisada?

## Checklist de inventário

Antes de testar, listar:

1. Todas as **telas** da área auditada
2. Todos os **componentes únicos** (não compartilhados) usados
3. Todos os **breakpoints** que precisam funcionar (desktop, tablet, mobile)
4. Todos os **estados de tela** previstos (loading, empty, error, success)

## Checklist de verificação

### Design system

- [ ] Tipografia consistente (mesma família e escala em todos os textos)
- [ ] Cores vêm de tokens/variáveis, nunca hardcoded
- [ ] Espaçamento usa escala consistente (não valores arbitrários)
- [ ] Componentes shadcn/ui usados em vez de versões customizadas redundantes
- [ ] Bordas e radius consistentes
- [ ] Ícones todos da mesma biblioteca (Lucide), mesmo tamanho onde fazem o mesmo papel

### Responsividade

- [ ] Layout funciona em viewport de 375px de largura (iPhone SE)
- [ ] Layout funciona em viewport de 768px (iPad)
- [ ] Layout funciona em viewport de 1440px+ (desktop comum)
- [ ] Sem scroll horizontal indesejado em nenhum breakpoint
- [ ] Botões e inputs alcançáveis com toque (mínimo 44x44px em mobile)
- [ ] Modais e drawers respeitam mobile (drawer bottom em mobile, modal centralizado em desktop)
- [ ] Tabelas com muitas colunas têm estratégia mobile (scroll horizontal, accordion, ou cards)

### Dark mode (se houver)

- [ ] Todas as superfícies têm cor adequada em ambos os modos
- [ ] Contraste suficiente em ambos os modos (WCAG AA mínimo)
- [ ] Imagens e ícones se adaptam ou têm versão para cada modo
- [ ] Nenhum texto invisível por color: black com background dark
- [ ] Toggle entre modos é instantâneo, sem flash de tema errado

### Estados de tela

- [ ] **Loading state** com skeleton ou spinner, não tela branca
- [ ] **Empty state** com mensagem útil e CTA para criar primeiro item
- [ ] **Error state** com mensagem compreensível (não "Error" só) e ação de retry
- [ ] **Success state** com feedback claro (toast, ícone, redirect)
- [ ] Estados intermediários (parte carregada, parte ainda carregando) bem tratados

### Microinterações e feedback

- [ ] Hover states em elementos clicáveis
- [ ] Focus visible em navegação por teclado
- [ ] Loading durante actions (botão fica disabled, mostra spinner)
- [ ] Transições suaves (não abruptas) em mudanças de estado
- [ ] Animações respeitam `prefers-reduced-motion`
- [ ] Toasts aparecem em posição consistente
- [ ] Confirmações de ações destrutivas usam tom apropriado (vermelho, ícone de aviso)

### Acessibilidade básica

- [ ] Cada input tem label associado
- [ ] Botões têm texto descritivo (não só ícone)
- [ ] Imagens têm `alt` apropriado
- [ ] Hierarquia de headings (h1, h2, h3) faz sentido
- [ ] Cores não são o único meio de transmitir informação (usar ícone + cor)
- [ ] Navegação por Tab faz sentido e não fica presa

### Conteúdo e copy

- [ ] Linguagem consistente (formal vs informal, vc vs você)
- [ ] Sem placeholder text esquecido ("Lorem ipsum", "TODO", etc.)
- [ ] Mensagens de erro úteis (dizem o que fazer, não só o que falhou)
- [ ] Sem termos técnicos que confundem o usuário final
- [ ] Português correto, sem em-dash (preferência específica do Toni)

## Verificação de correlação

- [ ] Componentes que aparecem em múltiplas telas se comportam igual
- [ ] Cores de status (sucesso, erro, warning, info) são consistentes em todo o app
- [ ] Densidade de informação é apropriada (não excessivamente vazio nem sobrecarregado)
- [ ] Hierarquia visual conduz o olho na ordem certa de leitura

## Como executar a verificação

1. Subir o ambiente local
2. Para cada tela, abrir em três tamanhos de viewport (DevTools, modo responsivo)
3. Tirar screenshots de cada tela em cada estado (loading, empty, error, success)
4. Comparar lado a lado com outras telas do mesmo produto
5. Pedir pra alguém leigo olhar e descrever o que entende — gaps de UX aparecem rapidamente
6. Testar navegação só com teclado (Tab, Enter, Esc)
7. Forçar dark mode se aplicável e repetir verificações

## Sinais clássicos de gap de UX

- Telas com aparência completamente diferentes umas das outras
- Botão primário em uma tela é azul, em outra é verde, em outra é roxo
- Loading state é só "Carregando..." em texto puro
- Empty state diz "Nenhum item encontrado" mas não tem botão de criar
- Erro genérico "Algo deu errado" sem ação possível
- Modal que ocupa a tela inteira no mobile sem possibilidade de fechar
- Texto cortado em mobile por width fixo
- Tabela com 8 colunas inutilizável em mobile
- Espaçamento errático (10px aqui, 12px ali, 16px acolá sem motivo)
- Lorem ipsum, "Texto exemplo" ou TODO em produção
- Mistura de "vc" e "você" ou "tu" no mesmo fluxo

Cada um desses entra no relatório.

## Específico para SaaS B2B (Veltzy, Lean Governance)

Considerar adicionalmente:

- [ ] White-label friendly (ou pelo menos preparado para customização visual futura)
- [ ] Telas vazias têm dignidade (cliente vai abrir e talvez ver pouco no início)
- [ ] Onboarding inicial cria sensação de progresso (não joga o cliente em dashboard vazio)
- [ ] Dashboard transmite competência mesmo com poucos dados
- [ ] Linguagem é apropriada para CEO de PME, não desenvolvedor
