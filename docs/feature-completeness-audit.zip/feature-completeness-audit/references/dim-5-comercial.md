# Dimensão 5 — Comercial

## Pergunta central

Se eu mostrar isso pro cliente amanhã, ele assina hoje?

Esta é a dimensão mais subjetiva e a mais importante. Uma feature pode estar tecnicamente perfeita e comercialmente inerte. Esta dimensão existe para forçar o crivo comercial sobre o que foi construído.

## Aplicação primária: Veltzy

O Veltzy é o produto SDR IA da Veltz. Está sendo construído para ser o grande case da consultoria. Cada feature precisa passar não só pelos critérios técnicos, mas pelos critérios de:

1. **Valor percebido** — o cliente sente que está recebendo algo poderoso?
2. **Demonstrabilidade** — dá pra mostrar em demo de 15 minutos e impressionar?
3. **Entregável tangível** — o cliente leva algo embora (relatório, lead, dashboard, integração ativa)?
4. **Encaixe no ecossistema** — conecta com o que cliente já usa (CRM, WhatsApp, e-mail, planilha)?

## Checklist de inventário

Antes de avaliar, listar:

1. Qual é a **promessa central** que essa feature ajuda a entregar?
2. Qual é o **caso de uso primário** que o cliente vai querer ver?
3. Qual é o **artefato concreto** que essa feature gera?
4. Qual é o **next step** depois que o cliente usa essa feature?

## Checklist de verificação

### Valor percebido

- [ ] A feature resolve uma dor real e nomeável do cliente
- [ ] O resultado da feature é visível em menos de 5 minutos de uso
- [ ] Existe um "momento aha" claro quando o cliente percebe o valor
- [ ] A feature não exige conhecimento técnico para ser apreciada
- [ ] O cliente consegue explicar pra outro o que a feature faz, em uma frase

### Demonstrabilidade em demo

- [ ] Existe um "happy path" de demonstração de 5 a 15 minutos
- [ ] Os dados de exemplo (seed) tornam a demo crível
- [ ] Não há gambiarras visíveis que precisam de "ignora isso aqui"
- [ ] Telas vazias da demo têm dignidade ou são puladas
- [ ] Performance é boa o suficiente para não constranger ao vivo
- [ ] Existe plano B se algo falhar na demo (ambiente staging confiável)

### Entregável tangível

- [ ] A feature gera algo que o cliente leva embora ou consegue compartilhar
- [ ] Esse "algo" pode ser: relatório PDF, planilha exportada, link compartilhável, dashboard com URL, mensagem enviada, lead qualificado, contrato gerado
- [ ] O entregável tem branding apropriado (logo, identidade visual)
- [ ] O entregável é apresentável a terceiros sem vergonha

### Encaixe no ecossistema

- [ ] Conecta com pelo menos uma ferramenta que o cliente já usa
- [ ] Tem caminho claro para exportar dados (não fica preso na plataforma)
- [ ] Tem caminho claro para importar dados (não obriga digitação manual)
- [ ] Suporta integrações nativas comuns (WhatsApp, Gmail, Google Sheets, HubSpot, etc.)
- [ ] Webhooks ou API pública permitem integrações customizadas

### Posicionamento e narrativa

- [ ] A feature reforça o posicionamento "SDR IA que faz a diferença no negócio"
- [ ] A feature tem nome claro, sem jargão técnico
- [ ] Tem texto de apoio (tooltip, helper, video) que explica o porquê
- [ ] Não compete com outras features do produto (cada uma tem papel claro)
- [ ] Cabe em um pitch de uma frase: "Veltzy faz X, Y e Z"

### Métricas de sucesso

- [ ] Existe forma de medir se o cliente está usando a feature
- [ ] Existe forma de medir se a feature está gerando o resultado prometido
- [ ] Esses dados podem virar case ou prova social no futuro
- [ ] O cliente pode ver as próprias métricas de uso e resultado

## Verificação de correlação

- [ ] As features juntas contam uma história coerente
- [ ] Não há features órfãs que não se conectam ao fluxo principal
- [ ] O cliente sabe a ordem em que deve usar as features
- [ ] Existe progressão de valor: feature básica → feature intermediária → feature avançada

## Como executar a verificação

### Teste do amigo céptico
Imagine um amigo CEO de PME, céptico de IA. Mostre a feature pra ele mentalmente. O que ele perguntaria? Onde ele mostraria desconfiança? Onde ele se animaria?

### Teste do "e daí?"
Para cada feature, pergunte "e daí?" três vezes seguidas:
- "Tem dashboard de leads." E daí?
- "Mostra quais leads estão mais quentes." E daí?
- "Posso priorizar contato com quem tem maior chance de fechar." E daí?
- "Vendo mais com menos esforço."

Se você não chegar em uma resposta de valor de negócio em 3 níveis, a feature está distante demais do valor real.

### Teste do print do WhatsApp
Se você fizer print da feature e mandar pro cliente no WhatsApp, ele entende o valor sem você explicar?

### Teste da demo de 5 minutos
Você consegue mostrar essa feature em 5 minutos de demo e gerar interesse genuíno? Se não, ou a feature não tem valor comercial, ou a UX está enterrando o valor.

## Sinais clássicos de gap comercial

- Feature técnica impressionante que não resolve dor nomeável
- Feature que precisa de tutorial de 20 minutos pra ser entendida
- Resultado que só aparece depois de semanas de uso
- Não gera artefato exportável ou compartilhável
- Funciona isolada, não conecta com nada do cliente
- Nome técnico ou jargão (tipo "agente autônomo orquestrado")
- Promete muito e entrega o mínimo
- Promete pouco mas tem mais valor escondido (também é um problema, é falha de comunicação)
- Demo precisa de "ignora isso, ignora aquilo"
- Cliente vê e pergunta "ok... e onde tá o que vai me ajudar a vender mais?"

Cada um desses entra no relatório com severidade Alta ou Crítica.

## Pergunta final

Antes de fechar a auditoria comercial, responder por escrito:

> "Em uma frase, qual é o motivo pelo qual o cliente vai pagar pelo Veltzy?"

Se a resposta sair clara e a feature auditada contribui visivelmente para essa resposta, ela passa. Se a resposta sai vaga ou a feature não contribui, há trabalho a fazer.
