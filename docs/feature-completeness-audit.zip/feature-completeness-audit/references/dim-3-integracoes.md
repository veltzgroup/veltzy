# Dimensão 3 — Integrações

## Pergunta central

As integrações com sistemas externos funcionam de ponta a ponta, com erro tratado e logs?

## Checklist de inventário

Antes de testar, listar:

1. Todas as **APIs externas** chamadas pela feature (Resend, Stripe, Z-API, OpenAI, Anthropic, etc.)
2. Todos os **webhooks** que a feature recebe
3. Todas as **Edge Functions** envolvidas
4. Todas as **chaves e secrets** necessários
5. Todos os **rate limits** aplicáveis

## Checklist de verificação

### Configuração de credenciais

- [ ] Todas as API keys estão no `.env.local`
- [ ] Todas as API keys estão configuradas no Vercel (Production, Preview, Development)
- [ ] Nenhuma chave está hardcoded no código
- [ ] `.env*` está no `.gitignore`
- [ ] Chaves de teste vs produção estão claramente separadas

### Chamadas de saída (outbound)

Para cada API externa que a feature chama:

- [ ] Endpoint correto da doc oficial atualizada
- [ ] Headers de autenticação corretos
- [ ] Timeout configurado (não pendurar para sempre)
- [ ] Retry com backoff em erros transitórios
- [ ] Erros são capturados e logados
- [ ] Erros são exibidos pro usuário de forma compreensível
- [ ] Resposta é validada antes de ser usada (não confiar cego)
- [ ] Dados sensíveis não vazam em logs

### Webhooks de entrada (inbound)

Para cada webhook que a feature recebe:

- [ ] Endpoint público (não atrás de auth) ou com signature verification
- [ ] Signature verificada quando aplicável (Stripe, Z-API, etc.)
- [ ] Resposta 200 enviada rapidamente (antes de processar pesado)
- [ ] Idempotência tratada (mesmo evento chegando duas vezes)
- [ ] Eventos não reconhecidos são logados, não falham
- [ ] Edge Function deployada com `--no-verify-jwt` se aplicável

### Edge Functions (Supabase)

- [ ] Function deployada no projeto certo
- [ ] Secrets configurados via `supabase secrets set`
- [ ] CORS configurado se função é chamada do browser
- [ ] Logs estão sendo gravados (verificar via Dashboard)
- [ ] Erros são capturados, não derrubam a function silenciosamente
- [ ] Tempo de execução está dentro do limite (10s para HTTP, 60s para background)

### Logs e observabilidade

- [ ] Cada chamada externa gera log de início e fim
- [ ] Erros geram log com contexto (qual usuário, qual ação, qual payload)
- [ ] Logs ficam acessíveis (Vercel logs, Supabase logs, Sentry, etc.)
- [ ] Dados sensíveis (senhas, tokens) não aparecem nos logs
- [ ] Existe forma de buscar logs por usuário ou ID de transação

### Rate limits e custos

- [ ] Limites de cada API externa são conhecidos
- [ ] Existe proteção contra exceder rate limit (queue, throttle, debounce)
- [ ] Custos por chamada estão mapeados (especialmente APIs de IA)
- [ ] Existe alerta ou limite mensal para evitar surpresa

## Verificação de correlação

- [ ] Falha de uma API externa não derruba a feature inteira
- [ ] Reprocessamento manual é possível quando webhook falha
- [ ] Estados intermediários são salvos (não perde dados se a API cair no meio)
- [ ] Filas ou retries não acumulam infinitamente

## Como executar a verificação

### Para chamadas outbound

1. Abrir DevTools com Network tab
2. Executar a ação que dispara a chamada
3. Verificar:
   - Request foi feito
   - Status code retornado
   - Payload de resposta válido
   - Tempo de resposta razoável
4. Forçar erro:
   - Quebrar a API key temporariamente
   - Confirmar que erro aparece pro usuário de forma clara
   - Confirmar que erro foi logado
   - Restaurar a key

### Para webhooks inbound

1. Disparar evento real no sistema externo (criar customer no Stripe, mandar mensagem no Z-API, etc.)
2. Verificar logs da Edge Function:
   ```bash
   npx supabase functions logs <nome-function> --tail
   ```
3. Confirmar que evento foi processado
4. Confirmar que estado correto ficou no banco
5. Disparar o mesmo evento de novo e verificar idempotência

### Para Edge Functions

1. Chamar a function via cURL ou Postman
2. Verificar status code, response body, tempo
3. Verificar logs no Dashboard do Supabase
4. Testar com payload inválido e ver se erro é tratado

## Sinais clássicos de gap de integração

- API key vazia em produção (env var não configurada no Vercel)
- Edge Function retorna 401 silenciosamente porque webhook não tem JWT
- Webhook chega mas não é processado porque signature não foi verificada
- API externa demora 30s e usuário fica sem feedback
- Erro 500 sem nenhum log para investigar
- Dado parcial salvo: parte da integração funcionou, outra não, e o estado fica inconsistente
- Rate limit estourado e usuário recebe erro genérico
- Custo explodindo porque retry automático não tem limite

Cada um desses vai pro relatório.

## Armadilhas específicas conhecidas

### Z-API
- Status de conexão é uma string específica que precisa ser comparada literalmente
- Webhook precisa de HTTPS e response 200 rápido
- Edge Function recebendo Z-API precisa de `--no-verify-jwt`

### Resend
- Domain verification antes de mandar de domínio próprio
- API key separada por ambiente

### Anthropic API (Claude)
- Verificar nome do modelo atual na doc oficial (muda)
- Streaming requer handling específico
- Tool use tem schema próprio

### Stripe
- Webhook signature verification obrigatória
- Test mode keys vs live mode keys
- Customer portal precisa configuração no dashboard
