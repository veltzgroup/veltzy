# Dimensão 1 — Funcional

## Pergunta central

Tudo que está visível na tela faz o que parece que faz?

## Checklist de inventário

Antes de testar, listar:

1. Todas as **rotas** envolvidas na área auditada
2. Todos os **botões e CTAs** em cada rota
3. Todos os **formulários** e seus submits
4. Todos os **links** e navegações
5. Todos os **estados condicionais** (modal, drawer, popover, tooltip)

## Checklist de verificação

Para cada item do inventário, validar:

### Botões e CTAs
- [ ] Tem `onClick` ou handler ligado, não está só decorativo
- [ ] O handler chama uma função real, não um TODO
- [ ] A função executa até o fim sem erro
- [ ] Após executar, há feedback visual (toast, mudança de estado, redirect)
- [ ] Se requer confirmação, o modal de confirmação existe e funciona
- [ ] Estado disabled funciona quando deveria (ex.: durante loading)

### Formulários
- [ ] Cada campo tem validação apropriada (required, email, mínimo de caracteres, etc.)
- [ ] Mensagens de erro aparecem inline, próximas ao campo
- [ ] Submit envia para o endpoint correto
- [ ] Estado de loading aparece durante submit
- [ ] Sucesso resulta em ação clara (redirect, toast, reset, etc.)
- [ ] Erro do servidor é exibido de forma compreensível
- [ ] Formulário pode ser resubmetido após erro

### Navegação
- [ ] Cada link leva a uma rota que existe
- [ ] Rotas dinâmicas (`/cliente/[id]`) recebem parâmetros válidos
- [ ] Voltar (back button do navegador) funciona corretamente
- [ ] Deep links funcionam (colar URL na barra abre a tela esperada)
- [ ] Rotas protegidas redirecionam quando sem auth

### Estados de tela
- [ ] **Loading state** existe enquanto dados carregam
- [ ] **Empty state** existe quando não há dados (com CTA pra criar primeiro item)
- [ ] **Error state** existe quando algo falha (com opção de retry)
- [ ] **Success state** comunica conclusão de ação
- [ ] Skeletons ou spinners aparecem em fetch inicial

### Componentes condicionais
- [ ] Modais abrem e fecham corretamente
- [ ] Modais não bloqueiam quando não deveriam
- [ ] Tooltips e popovers aparecem no hover/click correto
- [ ] Dropdowns selecionam o item escolhido
- [ ] Drawers respeitam mobile vs desktop

## Verificação de correlação

Os passos individuais podem estar OK mas o fluxo pode estar furado. Validar:

- [ ] Fluxo completo end-to-end funciona sem reload manual
- [ ] Dados criados em um lugar aparecem em outro lugar que deveria refletir
- [ ] Ações em um componente atualizam outros componentes que dependem
- [ ] Estados de loading/error/success se propagam corretamente entre componentes

## Como executar a verificação

1. Subir o ambiente local (`npm run dev`)
2. Abrir DevTools com Console aberto
3. Para cada rota:
   - Abrir a rota
   - Capturar erros do console (se houver)
   - Tentar cada botão e formulário
   - Anotar o que falhou e o que pareceu inconsistente
4. Para o fluxo completo:
   - Executar do começo ao fim como um usuário real faria
   - Não pular etapas, não usar atalhos
   - Anotar cada momento de fricção

## Sinais clássicos de gap funcional

- Botão que parece clicável mas não acontece nada
- Formulário que aceita dados inválidos sem reclamar
- Loading state que nunca termina
- Empty state vindo "Carregando..." em vez do conteúdo correto
- Dois itens criados quando só era pra criar um (clique duplo permitido)
- Erro 500 no console após uma ação que pareceu "funcionar"
- Toast de sucesso aparece mas a ação não foi salva no banco
- Modal que não fecha ao clicar fora ou no X

Cada um desses é um gap a registrar no relatório.
