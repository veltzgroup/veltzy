---
name: feature-completeness-audit
description: Auditoria sistemática de completude de features ou áreas inteiras de um produto SaaS, antes de mostrar pra cliente ou colocar em produção. Use esta skill SEMPRE que o usuário quiser fazer um pente fino em uma parte do app, validar que algo está realmente pronto, ou identificar gaps entre "implementado" e "vendável". Acione esta skill quando o usuário disser coisas como "está pronto?", "passa um pente fino", "audita esse fluxo", "preciso fechar essa parte", "vou mostrar pra cliente amanhã", "essa feature está completa?", ou estiver preparando demo. Esta skill cobre cinco dimensões (funcional, dados, integrações, UX, comercial) e produz relatório com gaps acionáveis. É mais ampla que verificação de implementação isolada — audita o conjunto.
---

# Feature Completeness Audit

Skill para auditoria sistemática de features ou áreas de um produto antes de elas serem consideradas prontas para cliente ou produção. Foi construída para fechar a lacuna entre "construído com SDD" e "vendável".

## Quando usar

Use esta skill em três momentos:

1. **Antes de mostrar para cliente** — você marcou demo, quer garantir que não vai pegar nada feio ao vivo
2. **Antes de declarar feature concluída** — terminou a implementação SDD, quer ter certeza que o conjunto faz sentido
3. **Pente fino periódico** — uma vez por sprint, audita uma área inteira para encontrar dívida acumulada

## Princípio central

> Implementado não é o mesmo que pronto. Pronto não é o mesmo que vendável.

Uma feature pode estar tecnicamente correta mas funcionalmente incompleta. Pode estar funcionalmente completa mas comercialmente inerte. Esta skill audita o conjunto, considerando que partes individuais podem estar OK enquanto o todo está furado.

## As cinco dimensões da auditoria

```
┌──────────────┬──────────────┬──────────────┬──────────────┬──────────────┐
│ 1. FUNCIONAL │ 2. DADOS     │ 3. INTEGRAÇÃO│ 4. UX/VISUAL │ 5. COMERCIAL │
├──────────────┼──────────────┼──────────────┼──────────────┼──────────────┤
│ Todo botão   │ Persiste o   │ APIs end-to- │ Design system│ Demonstrável?│
│ funciona?    │ que diz?     │ end?         │ consistente? │              │
│ Estados      │ RLS OK?      │ Webhooks     │ Mobile?      │ Gera entrega-│
│ loading/     │ Tipos batem? │ chegam?      │ Dark mode?   │ vel?         │
│ error/empty? │ Queries      │ Logs gravam? │ Estados de   │ Tem "uau"?   │
│ Navegação    │ retornam o   │ Retries?     │ erro visíveis│ Conectado ao │
│ leva a algo? │ esperado?    │              │              │ ecossistema? │
└──────────────┴──────────────┴──────────────┴──────────────┴──────────────┘
```

Detalhe de cada dimensão:
- `references/dim-1-funcional.md`
- `references/dim-2-dados.md`
- `references/dim-3-integracoes.md`
- `references/dim-4-ux-visual.md`
- `references/dim-5-comercial.md`

## Comando principal

`/audit <área ou feature>`

Exemplos:
- `/audit fluxo-cadastro-cliente`
- `/audit dashboard-sdr`
- `/audit onboarding-completo`
- `/audit demo-veltzy` (audita o que será mostrado em demo)

O prompt canônico está em `assets/prompts/audit.md`.

## Output esperado

A skill produz um relatório no formato `docs/audits/<area>-<data>.md` com:

1. **Sumário executivo** — quantos gaps por dimensão, semáforo geral (verde/amarelo/vermelho)
2. **Inventário** — todas as telas, fluxos, endpoints e tabelas envolvidas
3. **Achados por dimensão** — cada gap com severidade, arquivo afetado, e ação recomendada
4. **Gaps comerciais** — específicos para Veltzy, considerando se é vendável
5. **Plano de ataque** — ordem priorizada do que corrigir primeiro

Veja `assets/templates/audit-report.template.md` para o formato completo.

## Severidades

Cada gap recebe uma severidade:

- **🔴 Crítico** — impede uso ou demonstração; corrigir antes de qualquer outra coisa
- **🟠 Alto** — funciona mas com fricção visível; cliente vai notar
- **🟡 Médio** — gap real mas tolerável a curto prazo; corrigir antes de produção
- **🟢 Baixo** — polish; pode entrar em backlog

## Como a auditoria executa

Para cada dimensão, a skill faz três passes:

1. **Inventário** — lista o que existe na área auditada
2. **Verificação** — testa cada item contra critérios da dimensão
3. **Correlação** — checa se as partes formam um todo coerente

A correlação é o passo mais importante. É onde aparecem gaps tipo "cadastro funciona, dashboard funciona, mas o cadastro não cria o registro que o dashboard mostra".

## Anti-padrões da auditoria

Evite ao executar:

1. **Auditar com o app sem rodar** — sempre subir o ambiente local, abrir no navegador, abrir DevTools
2. **Confiar em "auto-audit" da IA** — IA lendo arquivos e dizendo OK não prova nada, exatamente como no PVO
3. **Auditar tudo de uma vez** — escolher uma área específica, ir fundo, voltar pra próxima
4. **Auditar sem critério comercial** — Veltzy especialmente precisa do filtro "isso ajuda a vender?"

## Diferença para o Protocolo de Verificação Obrigatório

| | PVO (claude-code-sdd) | Audit (esta skill) |
|---|---|---|
| Escopo | Uma feature recém-implementada | Uma área inteira do produto |
| Momento | Final da Fase 3 do SDD | Antes de demo ou produção |
| Foco | A implementação específica está correta? | O conjunto é vendável? |
| Inclui ângulo comercial | Não | Sim |

Use os dois juntos: PVO valida cada feature individualmente, esta skill audita o conjunto.

## Específico para o Veltzy

Para o Veltzy, a Dimensão 5 (Comercial) é especialmente crítica. Veja `references/dim-5-comercial.md` para os critérios de "vendável" e "demonstrável" pensados pro contexto SDR IA.

A pergunta-chave que essa dimensão responde: **"Se eu mostrar isso pro cliente amanhã, ele assina hoje?"**

## Referências

- `references/dim-1-funcional.md` → checklist funcional detalhado
- `references/dim-2-dados.md` → checklist de dados e Supabase
- `references/dim-3-integracoes.md` → checklist de integrações externas
- `references/dim-4-ux-visual.md` → checklist UX e design system
- `references/dim-5-comercial.md` → checklist comercial (Veltzy-aware)
- `assets/prompts/audit.md` → prompt canônico do `/audit`
- `assets/templates/audit-report.template.md` → template de relatório
